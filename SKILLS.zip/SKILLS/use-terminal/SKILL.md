---
name: use-terminal
description: "Use when the user wants Codex to work through the terminal: inspect files, run shell commands, explain command output, search a project, manage local files, or translate a goal into terminal steps. Trigger on requests about the command line, shell usage, CLI tools, or terminal-based troubleshooting and automation."
---

# Use Terminal

## Overview

Use the terminal as the primary interface for local inspection and execution. Start with the minimum command needed to build context, then run targeted commands that solve the user's task and report the result plainly.

## Workflow

1. Inspect the current context first.
2. Prefer read-only discovery before any command with side effects.
3. Use the fastest native CLI that fits the job.
4. Run the smallest command that answers the question or completes the step.
5. Summarize the result in user-facing language instead of pasting raw output unless the user asked for it.

## Starting Services

When the user wants a local app or web service started from the terminal, use this sequence:

1. Inspect the repo for the real entrypoint, dependency file, required environment variables, and documented startup command.
2. Prefer the repo's own start command or task runner over guessing.
3. If the service can be validated with a short-lived command, run it in the sandbox first.
4. If the user explicitly wants their Terminal window used, attempt to launch Terminal.app or send the command there when the environment exposes GUI control.
5. If `~/Downloads/TerminalBridge/terminal_bridge.py` exists and the bridge state file reports `idle` or `busy`, prefer writing a command request into `~/Downloads/TerminalBridge/queue/` and reading the result from `~/Downloads/TerminalBridge/results/`.
6. Treat the bridge as opt-in local infrastructure: it only works after the user starts it in their own Terminal.
7. If the service needs a long-running process, local socket binding, or a real terminal window, assume the sandbox may block it and be ready to switch to the user's actual Terminal or the bridge.
8. If Terminal.app is not visible to the environment or GUI automation fails, state that as a hard platform limitation rather than implying the skill can override it.
9. Verify startup with the smallest meaningful check: logs, an HTTP request, or an in-process test client when socket binding is blocked.
10. State clearly whether the service is actually listening, only smoke-tested in-process, or blocked by the environment.

## Command Selection

- Prefer `rg` for text search and `rg --files` for file discovery.
- Prefer direct single-purpose commands over long shell one-liners.
- Always set an explicit working directory when running a command.
- Avoid `cd` when the command runner supports a working directory parameter.
- Use read-only commands such as `pwd`, `ls`, `find`, `rg`, `sed`, `cat`, `git status`, and `git diff` to gather context before editing or deleting anything.

## Safety Rules

- Explain commands with side effects immediately before running them.
- Avoid destructive commands unless the user explicitly asked for that outcome.
- Never assume a command succeeded; check the exit status or inspect the resulting files.
- If a command fails, use the error message to choose the next diagnostic step instead of retrying blindly.
- If a task can be completed by reading the filesystem or editing files directly, avoid unnecessary shell complexity.
- Do not claim a web service is running unless you verified that the process stayed alive and accepted a request or equivalent check.
- If GUI automation or socket binding is blocked, say that directly and give the user the exact command to run in their own Terminal.
- Do not imply that editing the skill changes sandbox, GUI, or OS-level permissions. Skills affect workflow, not platform capabilities.
- Do not claim the Terminal Bridge is active unless `~/Downloads/TerminalBridge/state.json` exists and shows a live status written by the bridge process.

## Common Request Patterns

- For "find where this is defined," search with `rg` and open only the relevant files.
- For "run this project," inspect the repo first for the correct entrypoint or task runner.
- For "start this server" or "run this web app," check the documented startup command, confirm dependencies, try a sandbox smoke test, and fall back to an exact user-terminal command when the environment blocks a real listener.
- For "clean up files," list the targets first, then perform the requested action carefully.
- For "what does this command do," explain the command in plain language and note risks, inputs, and outputs.
- For "fix this terminal error," capture the exact failing command, error text, working directory, and nearby config files before changing anything.

## Output Style

- Keep user updates short and concrete.
- Report what was run, what changed, and what still blocks completion.
- When the user asks for command output, provide the relevant lines or summarize the important parts.
- Prefer actionable next steps over generic terminal advice.
